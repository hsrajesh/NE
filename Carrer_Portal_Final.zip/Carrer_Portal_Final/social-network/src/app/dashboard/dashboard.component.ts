import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { forEach } from '@angular/router/src/utils/collection';
import { SocialService } from '../social.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  count=0;
  user_details;
  user_profile;
  fnames;fnamee;
  ename;id;email;mob;
  fname;lname;skill;hdeg;collg;from;to;cname;exp;clocation;city;desig;pecent;stream;

  constructor(private http:HttpClient,private router:Router,private cd:SocialService,private activate:ActivatedRoute)
  {
    this.activate.params.subscribe((parameters)=>{
        this.id = parameters['id']
    })
    this.user_profile = this.cd.userData(this.id)
    .subscribe((data)=>{
      this.user_profile = data;
      this.showDetails()
    })

  }
  searchFriends()
   {
     if(this.fnamee == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fnamee) != -1)
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })
    }
   }
  showDetails()
  {
      this.fname = this.user_profile.user_firstname;
      this.lname = this.user_profile.user_lastname;
      this.city = this.user_profile.user_city;
      this.clocation = this.user_profile.user_location;
      this.skill = this.user_profile.user_skills;
      this.hdeg = this.user_profile.user_degree;
      this.from = this.user_profile.user_clgfrom;
      this.to = this.user_profile.user_clgto;
      this.collg = this.user_profile.user_college;
      this.pecent = this.user_profile.user_percentage;
      this.stream  = this.user_profile.user_stream;
      this.desig = this.user_profile.user_designation;
      this.cname = this.user_profile.user_cmpname;
      this.exp = this.user_profile.user_cmpexp;
     this.email = this.user_profile.user_email;
     this.mob = this.user_profile.user_mobile;
  }
  Save()
  {
    var emp = {id:this.id,mobile:this.mob,fname:this.fname,lname:this.lname,skill:this.skill,college:this.collg,from:this.from,to:this.to,cmpname:this.cname,cexp:parseInt(this.exp),location:this.clocation,city:this.city,designation:this.desig,stream:this.stream,percentage:this.pecent,highdegree:this.hdeg}
    var head = new HttpHeaders({'Content-Type':'application/json'})
    this.http.put("http://localhost:5000/getproffind",emp,{headers:head})
    .subscribe(()=>{
      this.router.navigate(['view',this.id])
    })
  }
  namef = new FormControl('',[Validators.required])
  namel = new FormControl('',[Validators.required])
  skills = new FormControl('',[Validators.required])
  mobile = new FormControl('',[Validators.required,Validators.pattern('[6-9][0-9]{9}')])
  user_city =new FormControl('',[Validators.required])
  high_degree =new FormControl('',[Validators.required])
  branch =new FormControl('',[Validators.required])
  collg_name =new FormControl('',[Validators.required])
  percentage =new FormControl('',[Validators.required,Validators.pattern('[0-9]{2,}')])
  From =new FormControl('',[Validators.required])
  To =new FormControl('',[Validators.required])
  cmp_name =new FormControl('',[Validators.required])
  cmp_location =new FormControl('',[Validators.required])
  cmp_exp =new FormControl('',[Validators.required])
  cmp_desig =new FormControl('',[Validators.required])

  getMobErrors()
  {
    return this.mobile.hasError('required')?'Cannot be Empty':this.mobile.hasError('pattern')?'Mobile Number Should be 10digits and first number must be from 6-9':'';
  }
  getBranchErrors()
  {
    return this.branch.hasError('required')?'Cannot be Empty':'';
  }
  getPercentErrors()
  {
    return this.percentage.hasError('required')?'Cannot be Empty':this.percentage.hasError('pattern')?'Minimum two digits required':'';
  }
  getFnameErrors()
  {
      return this.namef.hasError('required')?'Cannot be Empty':'';
  }
  getLnameErrors()
  {
      return this.namel.hasError('required')?'Cannot be Empty':'';
  }
  getSkillsErrors()
  {
      return this.skills.hasError('required')?'Cannot be Empty':'';
  }
  getCityErrors()
  {
      return this.user_city.hasError('required')?'Cannot be Empty':'';
  }
  getDegErrors()
  {
      return this.high_degree.hasError('required')?'Cannot be Empty':'';
  }
  getColgErrors()
  {
      return this.collg_name.hasError('required')?'Cannot be Empty':'';
  }
  getFromErrors()
  {
      return this.From.hasError('required')?'Cannot be Empty':'';
  }
  getToErrors()
  {
      return this.To.hasError('required')?'Cannot be Empty':'';
  }
  getCnameErrors()
  {
      return this.cmp_name.hasError('required')?'Cannot be Empty':'';
  }
  getClocaErrors()
  {
      return this.cmp_location.hasError('required')?'Cannot be Empty':'';
  }
  getCexpeErrors()
  {
      return this.cmp_exp.hasError('required')?'Cannot be Empty':'';
  }
  getCdesErrors()
  {
      return this.cmp_desig.hasError('required')?'Cannot be Empty':'';
  }

  ngOnInit() {
  }

}
