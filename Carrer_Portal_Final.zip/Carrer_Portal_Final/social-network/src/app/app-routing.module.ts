import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { ForgetComponent } from './forget/forget.component';
import { NotificationComponent } from './notification/notification.component';
import { FriendsComponent } from './friends/friends.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddComponent } from './add/add.component';
import { ViewprofileComponent } from './viewprofile/viewprofile.component';
import { AddpostComponent } from './addpost/addpost.component';

const routes: Routes =
[
  {path:'',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  {path:'home',component:HomeComponent},
  {path:'profile/:id',component:ProfileComponent},
  {path:'forget',component:ForgetComponent},
  {path:'notification/:id',component:NotificationComponent},
  {path:'friends',component:FriendsComponent},
  {path:'about/:id',component:DashboardComponent},
  {path:'add/:id',component:AddComponent},
  {path:'view/:id',component:ViewprofileComponent},
  {path:'addpost/:id',component:AddpostComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
