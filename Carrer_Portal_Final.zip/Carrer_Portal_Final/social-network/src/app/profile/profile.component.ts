import { Component, OnInit } from '@angular/core';
import { Router, Data, ActivatedRoute } from '@angular/router';
import { SocialService } from '../social.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FriendsComponent } from '../friends/friends.component';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
   d = new Date()
   id;
  fname;fnames;
  user_details;
  user_data;
  user_fname;count=0;likes;c=0;post_id;
  user_lname;clgyear;p;card;postname;
  post_details;fullname;
  user_clgyear;status;user_course;user_cllg;user_skills;user_degree;ucompnay;udesg;ucity;ucloaction
  likes_details;
  constructor(private router:Router,private cd:SocialService,private http:HttpClient,private activate:ActivatedRoute) {
    this.user_details = this.cd.getData()
    .subscribe((data)=>{
      this.user_details = data;
      this.p = this.user_details;
    })

    this.http.get("http://localhost:5000/getprof")
    .subscribe((data)=>{
      this.user_data = data;
    })
    this.activate.params.subscribe((parameters)=>{
        this.id = parameters['id'];
    })
    this.post_details = this.cd.userData(this.id).subscribe((data)=>{
      this.post_details  = data;
      this.checkData()
    })
  }
  searchFriends()
   {
     if(this.fname == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fname) != -1)
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })
    }
   }
   countLike(pid)
   {
      this.likes_details = this.cd.getLikes(pid).subscribe((data)=>{
       this.likes_details = data;
       this.likes_details.map((p,i)=>{
         this.c = p.likes;
       })
       alert(this.c);
     })
     this.count = this.c + 1;
     var body = {id:pid,count:this.count,postname:this.card}
     var head = new HttpHeaders({'Content-Type':'application/json'})
     this.http.put("http://localhost:5000/addcount",body,{headers:head}).subscribe(()=>{
       alert("added")
     })
   }
   checkData()
   {
    this.user_fname = this.post_details.user_firstname;
    this.user_lname = this.post_details.user_lastname;
    this.fullname = this.user_fname + this.user_lname;
    this.post_details.Posts.map((p,i)=>{
        this.postname = p.postname;
        this.likes = parseInt(this.p.post_id);
      })
   }
  ngOnInit() {
  }

}
