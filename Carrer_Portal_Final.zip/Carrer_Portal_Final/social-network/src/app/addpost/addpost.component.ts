import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-addpost',
  templateUrl: './addpost.component.html',
  styleUrls: ['./addpost.component.css']
})
export class AddpostComponent implements OnInit {
  id;fnamee;card;postname;postid;post_id;count=0;
  constructor(private activate:ActivatedRoute,private http:HttpClient,private route:Router) {
    this.activate.params.subscribe((parameters)=>{
      this.id = parameters['id']
    })
   }

  searchFriends()
  {

  }
  addPosts()
  {
    this.postid = (Math.random()*100);
    this.post_id = parseInt(this.postid)
    var body = {id:this.id,count:this.count,postid:this.post_id,postname:this.postname}
    var head  = new HttpHeaders({'Content-Type':'application/json'})
    this.http.put("http://localhost:5000/addposts",body,{headers:head})
    .subscribe(()=>{
      this.route.navigate(['profile',this.id])
      this.postname = "";
    })
  }
  ngOnInit() {
  }

}
