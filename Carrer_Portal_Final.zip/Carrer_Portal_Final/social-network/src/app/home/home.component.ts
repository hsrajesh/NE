import { Component, OnInit, Input} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { SocialService } from '../social.service';
// import { request } from 'http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  user_details;
  fname;
  fnames;
  request="Connection";namef ;namel;p;count=0;
  uid;post_details;fullname;postname;
  constructor(private router:Router,private http:HttpClient,private cd:SocialService,private activate:ActivatedRoute) {

    this.uid = this.activate.snapshot.paramMap.get('id')
    this.user_details = this.cd.getData()
    .subscribe((data)=>{
        this.user_details = data;
    })
    this.post_details = this.cd.userData(this.uid).subscribe((data)=>{
      this.post_details = data;
      this.PostData()
    })
   }
   searchFriends()
   {
     if(this.fname == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fname) != -1)
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })

    }
   }
   PostData()
   {
      this.namef = this.post_details.user_firstname;
      this.namel = this.post_details.user_lastname;
      this.fullname = this.namef + this.namel;
     this.p = this.post_details.Posts;
   }
   sendRequest()
   {
      this.request ='Connection Sent'
   }
  ngOnInit() {
  }
  countLike()
  {
      this.count=this.count + 1;
  }

}
