import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormControl, Validators } from '@angular/forms';
import { SocialService } from '../social.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
mail;pass;
logincred;
temp;
uid;
  constructor(private router:Router,private http:HttpClient,private cd:SocialService) {
    this.logincred = this.cd.getData()
    .subscribe((data)=>{
      this.logincred = data;
    })

  }
  email = new FormControl('',[Validators.required, Validators.email])
  password = new FormControl('',[Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$#@_]).{8,15}')])

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
        this.email.hasError('email') ? 'Not a valid email' :'';

  }

  getPassErrorMessages()
  {
    return this.password.hasError('required')?'Password is required':this.password.hasError('pattern')?'Password Should contain alphanumeric and spacial Characters':'';
  }
  login()
  {
    this.logincred.map((p,i)=>{
    if(p.user_email == this.mail && this.pass == p.user_password)
    {
        this.temp =1;
        this.uid = p.user_id;
    }

  })
  if(this.temp==1)
  {
    this.router.navigate(['/home',{id:this.uid,si:true}])
  }
  else
  {
    alert("invalid user and passwod")
  }
  }
  ngOnInit() {
  }


}
