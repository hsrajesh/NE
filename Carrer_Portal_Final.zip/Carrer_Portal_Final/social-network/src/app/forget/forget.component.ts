import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.css']
})
export class ForgetComponent implements OnInit {
mail;
userdata;
temp;
  constructor(private http:HttpClient) {

    this.http.get("http://localhost:5000/get").subscribe((data)=>{
      this.userdata = data;
     })
   }
   forget()
   {
    this.temp=0;
      this.userdata.map((b,i)=>{

        if(b.user_email == this.mail)
        {
          this.temp = 1;
        }
      })
      if(this.temp == 1)
      {
        alert("success")
      }
      else
      {
        alert("invalid")
      }
      this.mail =''
   }

  ngOnInit() {
  }

}
