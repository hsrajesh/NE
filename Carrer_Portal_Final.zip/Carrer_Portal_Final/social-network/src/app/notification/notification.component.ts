import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SocialService } from '../social.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {
  user_details;
  fname;
  id;
  fnames;
  likesCount;
  count;
  postname;
  constructor(private http:HttpClient,private cd:SocialService,private activate:ActivatedRoute) {
    this.http.get("http://localhost:5000/get")
    .subscribe((data)=>{
        this.user_details = data;
    })
    this.activate.params.subscribe((parameters)=>{
      this.id = parameters['id']
    })
    this.likesCount = this.cd.userData(this.id).subscribe((data)=>{
      this.likesCount = data;
      this.Likes()
    })
   }

  searchFriends()
   {
     if(this.fname == '')
     {
       this.fnames =''
     }
     else{
    let fna=[];
      this.user_details.map((c,i)=>{
        if(c.user_name.indexOf(this.fname) != -1 || c.user_name == this.fname )
        {
            fna.push(c.user_name)
            this.fnames=fna;
        }
      })
    }
   }
   Likes()
   {
      this.count = this.likesCount.Posts.likes;
      this.postname = this.likesCount.Posts.postname;
   }
  ngOnInit() {
  }

}
